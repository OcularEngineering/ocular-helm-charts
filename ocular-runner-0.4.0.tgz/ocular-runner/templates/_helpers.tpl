{{/* World app ports as a JSON list of ints; values may be single ports or "start-end" ranges. */}}
{{- define "runner.worldPorts" -}}
{{- $out := list -}}
{{- range concat .Values.worlds.ports (compact (list .Values.worlds.publishPorts)) -}}
{{- $s := toString . -}}
{{- if contains "-" $s -}}
{{- $r := splitList "-" $s -}}
{{- range untilStep (atoi (index $r 0)) (add1 (atoi (index $r 1)) | int) 1 -}}
{{- $out = append $out . -}}
{{- end -}}
{{- else -}}
{{- $out = append $out (atoi $s) -}}
{{- end -}}
{{- end -}}
{{- toJson $out -}}
{{- end -}}

{{/* Path-routed app hostnames (<label>.<worlds.host>) as a JSON list, sorted and unique. */}}
{{- define "runner.appHostnames" -}}
{{- $out := list -}}
{{- range $app, $label := .Values.worlds.pathRouting.appHosts -}}
{{- $out = append $out (printf "%s.%s" $label $.Values.worlds.host) -}}
{{- end -}}
{{- toJson ($out | uniq | sortAlpha) -}}
{{- end -}}

{{/* OCULAR_APP_HOSTS: app=label,... */}}
{{- define "runner.appHostsEnv" -}}
{{- $out := list -}}
{{- range $app, $label := .Values.worlds.pathRouting.appHosts -}}
{{- $out = append $out (printf "%s=%s" $app $label) -}}
{{- end -}}
{{- join "," $out -}}
{{- end -}}
