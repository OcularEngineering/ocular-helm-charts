{{/* World app ports as a JSON list of ints; values may be single ports or "start-end" ranges. */}}
{{- define "runner.worldPorts" -}}
{{- $out := list -}}
{{- range concat .Values.worlds.ports (compact (list .Values.worlds.publishPorts)) -}}
{{- $s := toString . -}}
{{- if contains "-" $s -}}
{{- $r := splitList "-" $s -}}
{{- range untilStep (atoi (index $r 0)) (add1 (atoi (index $r 1)) | int) 1 -}}
{{- $out = append $out . -}}
{{- end -}}
{{- else -}}
{{- $out = append $out (atoi $s) -}}
{{- end -}}
{{- end -}}
{{- toJson $out -}}
{{- end -}}
